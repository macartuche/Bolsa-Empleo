<?php
class JSecureConfig {
	var $publish = '1';
	var $enableMasterPassword = '0';
	var $master_password = '00be0f3bc3c448a2f4fcbc7b6e6b6746';
	var $passkeytype = 'url';
	var $key = '00be0f3bc3c448a2f4fcbc7b6e6b6746';
	var $options = '0';
	var $custom_path = 'plugins/system/404.html';
	var $sendemail = '0';
	var $sendemaildetails = '3';
	var $emailid = '';
	var $emailsubject = 'Access Admin';
	var $iptype = '0';
	var $iplist = '';
	var $mpsendemail = '0';
	var $mpemailsubject = 'Jsecure Details has been changed';
	var $mpemailid = '';
	var $adminType = '1';
	var $delete_log = '0';
}
?>