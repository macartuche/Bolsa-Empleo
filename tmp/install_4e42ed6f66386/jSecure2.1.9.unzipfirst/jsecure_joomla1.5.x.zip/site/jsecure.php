<?php
/**
 * jSecure components for Joomla!
 * Originally written for Joomla as jSecure by Ajay Lulia.
 *
 * @author      $Author: Ajay Lulia $
 * @copyright   Joomla Service Provider - 2010
 * @package     jSecure2.1.8
 * @license     http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @version     $Id: jsecure.php  $
 */
defined( 'JPATH_BASE' ) or die( 'Direct Access to this location is not allowed.' );
echo JText::_("There is no frontend component built in to jSecure.");
