<?php
/**
* @version		$Id: ca-ES.ignore.php 2008-03-17Z dverger $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @translation_author	Catalan Joomla Translation Team
* @translation_copyright  Copyright (C) Translation 2008  Catalan Joomla Translation Team - joomla.cat
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

$search_ignore[] = "i";
$search_ignore[] = "a";
$search_ignore[] = "al";
$search_ignore[] = "als";
$search_ignore[] = "de";
$search_ignore[] = "dels";
$search_ignore[] = "en";
?>
