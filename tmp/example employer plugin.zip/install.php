<?php
if ( ! ( defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

/**
 * this is a place holder.
 * this file is being called for installation.
 * You can use this file to create extra tables or folders 
 * Or You can use whatever you want on Plugin installation
 * Or You can leave empty or write message like currently we have done :)
 */


?>