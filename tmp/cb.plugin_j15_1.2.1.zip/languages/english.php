<?php
/*======================================================================*\
|| #################################################################### ||
|| # ---------------------------------------------------------------- # ||
|| # com_library is a native Library Management Component for Joomla  # ||
|| # This component is not free or public.							  # ||
|| # It's for only our licensed customer							  # ||
|| # If you are not a licensed customer, You are not allowed to use it# ||
|| # Developer: Ulas ALKAN											  # ||
|| # Date: Jan 2009													  # ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ------------ OUR COMPONENT IS NOT FREE SOFTWARE ---------------- # ||
|| # www.ulasalkan.com |  www.ulasalkan.com/forum/showthread.php?t=12 # ||
|| #################################################################### ||
\*======================================================================*/

if ( ! ( defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

DEFINE('_lkn_cb_job_title','Job Title');
DEFINE('_lkn_cb_category_title','Job Category');
DEFINE('_lkn_cb_location_title','Job Location');
DEFINE('_lkn_cb_no_job','This user does not own any job');
DEFINE('_lkn_cb_user_is_an_employer','This user is an employer');
DEFINE('_lkn_cb_user_is_a_job_seeker','This user is a job seeker');